import { useEffect, useMemo, useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { AnimatePresence, motion } from 'motion/react'
import {
  AlertTriangle, Check, Eye, FlaskConical, Loader2, Play, Plus, RotateCcw,
  ShieldCheck, Trash2, Sparkles, X,
} from 'lucide-react'
import { api } from '@/lib/api'
import { refresh } from '@/lib/refresh'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import {
  Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle,
} from '@/components/ui/sheet'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Textarea } from '@/components/ui/textarea'
import { Input } from '@/components/ui/input'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'

/**
 * Run a simulation, or build one.
 *
 * The raw JSON textarea this replaces produced a 400 whenever anyone typed
 * anything slightly wrong — which is every time, under demo pressure. Worse, it
 * demanded IDs. Nobody thinks in `PO-7712`; they think "the shipment of motor
 * driver ICs from the Shenzhen supplier".
 *
 * So the builder is generated from the backend's own event schema and populated
 * from the world as it currently stands. Picking a part narrows the shipment
 * list to that part. Picking a shipment shows you whose it is, locked, because a
 * scenario that names a supplier who has nothing to do with that order is not a
 * test, it is a typo. The IDs travel underneath and never surface.
 *
 * JSON stays, for the person who wants to write an eight-event adversarial
 * timeline by hand — with the schema beside it and a validator that names the
 * offending field rather than the offending request.
 */

const EXAMPLE = `[
  { "at_h": 0,  "type": "supplier_delay",
    "params": { "po_id": "PO-7712", "delay_days": 6 } },
  { "at_h": 4,  "type": "supplier_reply",
    "params": { "supplier_id": "SUP-33",
                "message": "We may be able to arrange around 500 units, subject to confirmation, at approximately Rs 145." },
    "note": "numbers present, commitment absent" },
  { "at_h": 8,  "type": "warehouse_reply",
    "params": { "component_id": "COMP-104", "usable_stock": 300,
                "quarantined_stock": 90 } },
  { "at_h": 12, "type": "supplier_claim",
    "params": { "po_id": "PO-7712", "claim": "dispatched" } },
  { "at_h": 13, "type": "tracking_state",
    "params": { "po_id": "PO-7712", "tracking_status": "not_shipped" } }
]`

/* ---------------------------------------------------------------- fields -- */

function Label_({ children, hint }) {
  return (
    <div className="mb-1.5">
      <span className="text-muted-foreground text-[10px] font-medium tracking-[0.12em]
                       uppercase">{children}</span>
      {hint && (
        <p className="text-muted-foreground/80 mt-1 text-[11px] leading-relaxed">{hint}</p>
      )}
    </div>
  )
}

/** One schema field, rendered as whatever it declares itself to be. */
function SchemaField({ field, value, onChange, context, focusComponent }) {
  const { type, label, help } = field

  if (type.startsWith('ref:')) {
    const source = {
      'ref:purchase_order': context.purchase_orders,
      'ref:component': context.components,
      'ref:supplier': context.suppliers,
      'ref:production_order': context.production_orders,
      'ref:warehouse': context.warehouses,
    }[type] ?? []

    // Context-aware: a chosen part narrows everything that hangs off a part.
    // This is what stops somebody building a scenario that cannot happen.
    let options = source
    if (field.filter_by === 'component_id' && focusComponent) {
      const narrowed = source.filter((o) =>
        o.component_id === focusComponent ||
        (o.components ?? []).includes(focusComponent) ||
        o.id === focusComponent)
      if (narrowed.length) options = narrowed
    }

    return (
      <div>
        <Label_ hint={help}>{label}</Label_>
        <Select value={value ?? ''} onValueChange={onChange}>
          <SelectTrigger className="h-9 w-full text-[12.5px]">
            <SelectValue placeholder={`choose a ${label.toLowerCase()}`} />
          </SelectTrigger>
          <SelectContent>
            {options.map((o) => (
              <SelectItem key={o.id} value={o.id} className="text-[12.5px]">
                {o.label ?? o.name ?? o.id}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {options.length < source.length && (
          <p className="text-muted-foreground/70 mt-1 text-[10.5px]">
            narrowed to the part you picked · {options.length} of {source.length}
          </p>
        )}
      </div>
    )
  }

  if (type === 'enum') {
    return (
      <div>
        <Label_ hint={help}>{label}</Label_>
        <Select value={value ?? field.default ?? ''} onValueChange={onChange}>
          <SelectTrigger className="h-9 w-full text-[12.5px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {field.options.map((o) => (
              <SelectItem key={o.value} value={o.value} className="text-[12.5px]">
                {o.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    )
  }

  if (type === 'int' || type === 'number') {
    return (
      <div>
        <Label_ hint={help}>{label}{field.unit ? ` (${field.unit})` : ''}</Label_>
        <Input type="number" value={value ?? field.default ?? ''}
               min={field.min} max={field.max} step={field.step ?? 1}
               onChange={(e) => onChange(e.target.value)}
               className="h-9 font-mono text-[12.5px] tabular-nums" />
      </div>
    )
  }

  return (
    <div>
      <Label_ hint={help}>{label}</Label_>
      <Textarea value={value ?? ''} rows={field.rows ?? 2}
                placeholder={field.placeholder}
                onChange={(e) => onChange(e.target.value)}
                className="text-[12.5px] leading-relaxed" />
    </div>
  )
}

/* ------------------------------------------------------------- new entity -- */

function NewSupplier({ context, onClose, onCreated }) {
  const [f, setF] = useState({
    name: '', component_id: '', unit_price: '100',
    lead_time_days: '3', available_quantity: '600', min_order_quantity: '1',
    quality_score: '0.9', reliability_score: '0.8', mode: 'ROAD', certifications: [],
  })
  const set = (k, v) => setF((p) => ({ ...p, [k]: v }))

  useEffect(() => {
    if (!f.component_id && context.components?.length) {
      set('component_id', context.components[0].id)
    }
  }, [context.components, f.component_id])

  const comp = context.components?.find((c) => c.id === f.component_id)
  const required = comp?.required_certifications ?? []
  const missing = required.filter((c) => !f.certifications.includes(c))

  const create = useMutation({
    mutationFn: () => api.createSupplier({
      name: f.name.trim() || 'Test Supplier',
      component_id: f.component_id,
      unit_price: Number(f.unit_price || 0),
      lead_time_days: Number(f.lead_time_days || 0),
      available_quantity: Number(f.available_quantity || 0),
      min_order_quantity: Number(f.min_order_quantity || 1),
      quality_score: Number(f.quality_score || 0.9),
      reliability_score: Number(f.reliability_score || 0.8),
      certifications: f.certifications, mode: f.mode,
    }),
    onSuccess: onCreated,
  })

  return (
    <div className="rounded-xl border p-4">
      <div className="flex items-center gap-2">
        <Sparkles className="text-primary size-3.5" />
        <span className="text-[13px] font-medium">Add a supplier to the world</span>
        <Button variant="ghost" size="sm" onClick={onClose}
                className="text-muted-foreground ml-auto h-6 px-1.5">
          <X className="size-3.5" />
        </Button>
      </div>
      <p className="text-muted-foreground mt-2 text-[11.5px] leading-relaxed">
        Build your own trap. &ldquo;The cheapest supplier has no AEC-Q100&rdquo; should be
        something you can construct in thirty seconds without touching our seed file.
        Anything you add here is flagged as a test entity and disappears on the next
        reset, so it cannot contaminate somebody else&rsquo;s run.
      </p>

      <div className="mt-4 flex flex-col gap-3.5">
        <div>
          <Label_>Name</Label_>
          <Input value={f.name} onChange={(e) => set('name', e.target.value)}
                 placeholder="Cutprice Semiconductors" className="h-9 text-[12.5px]" />
        </div>
        <div>
          <Label_>Supplies</Label_>
          <Select value={f.component_id} onValueChange={(v) => set('component_id', v)}>
            <SelectTrigger className="h-9 text-[12.5px]"><SelectValue /></SelectTrigger>
            <SelectContent>
              {(context.components ?? []).map((c) => (
                <SelectItem key={c.id} value={c.id} className="text-[12.5px]">
                  {c.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="grid grid-cols-2 gap-3">
          {[['unit_price', '₹ per unit'], ['available_quantity', 'Units available'],
            ['lead_time_days', 'Lead time (days)'], ['min_order_quantity', 'Minimum order'],
            ['quality_score', 'Quality 0–1'], ['reliability_score', 'Reliability 0–1'],
          ].map(([k, l]) => (
            <div key={k}>
              <Label_>{l}</Label_>
              <Input type="number" value={f[k]} onChange={(e) => set(k, e.target.value)}
                     className="h-9 font-mono text-[12.5px] tabular-nums" />
            </div>
          ))}
        </div>
        <div>
          <Label_>Certifications they hold</Label_>
          <div className="flex flex-wrap gap-1.5">
            {['AEC-Q100', 'ISO-9001', 'IATF-16949', 'IEC-62133'].map((c) => (
              <Button key={c} size="sm"
                      variant={f.certifications.includes(c) ? 'secondary' : 'outline'}
                      onClick={() => set('certifications',
                        f.certifications.includes(c)
                          ? f.certifications.filter((x) => x !== c)
                          : [...f.certifications, c])}
                      className="h-7 px-2.5 text-[11px] font-normal">{c}</Button>
            ))}
          </div>
        </div>

        {required.length > 0 && (
          <div className={`flex items-start gap-2 rounded-lg border px-3 py-2.5
                           text-[11.5px] leading-relaxed ${missing.length
                             ? 'border-warn/40 bg-warn/[0.07]' : 'border-ok/40 bg-ok/[0.07]'}`}>
            <ShieldCheck className={`mt-0.5 size-3.5 shrink-0 ${
              missing.length ? 'text-warn' : 'text-ok'}`} />
            <span>
              {missing.length
                ? <>{comp.name} requires <b>{required.join(', ')}</b>. Without{' '}
                    {missing.join(', ')} the solver will refuse them on certification —
                    which is probably the trap you are building.</>
                : <>Fully certified for {comp.name}. They will compete on price and
                    lead time like everyone else.</>}
            </span>
          </div>
        )}

        {create.error && (
          <p className="text-danger text-[11.5px]">{String(create.error.message)}</p>
        )}

        <Button size="sm" disabled={create.isPending || !f.component_id}
                onClick={() => create.mutate()} className="h-9">
          {create.isPending ? <Loader2 className="size-3.5 animate-spin" />
                            : <Plus className="size-3.5" />}
          Add them
        </Button>
      </div>
    </div>
  )
}

/* ---------------------------------------------------------------- builder -- */

function Builder({ schema, context, onRun, running }) {
  const types = Object.keys(schema ?? {})
  const [name, setName] = useState('')
  const [focus, setFocus] = useState('')
  const [type, setType] = useState(types[0] ?? '')
  const [params, setParams] = useState({})
  const [atH, setAtH] = useState('0')
  const [events, setEvents] = useState([])
  const [note, setNote] = useState('')
  const [creating, setCreating] = useState(false)
  const [check, setCheck] = useState(null)

  const spec = schema?.[type]

  // The schema arrives a beat after the drawer opens. Without this the event
  // picker initialises to '' and stays there — a form with nothing selectable,
  // which reads as broken rather than as still loading.
  useEffect(() => {
    if (!type && types.length) setType(types[0])
  }, [types, type])

  useEffect(() => { setParams({}); setNote('') }, [type])

  // Prefill an event's part filter from the focus, where the event takes one.
  useEffect(() => {
    if (!spec || !focus) return
    const f = spec.fields.find((x) => x.name === 'component_id')
    if (f) setParams((p) => ({ ...p, component_id: focus }))
  }, [focus, type])   // eslint-disable-line react-hooks/exhaustive-deps

  const missing = (spec?.fields ?? [])
    .filter((f) => {
      const v = params[f.name] ?? f.default
      return f.required && (v === undefined || v === null || String(v).trim() === '')
    })
    .map((f) => f.label)

  // What the chosen row implies, shown locked. A scenario naming a supplier who
  // has nothing to do with that order is a typo, not a test.
  const derived = useMemo(() => {
    if (!spec?.autofill) return []
    const out = []
    for (const [target, rule] of Object.entries(spec.autofill)) {
      const id = params[rule.from]
      if (!id) continue
      const row = (context.purchase_orders ?? []).find((p) => p.id === id)
      if (!row) continue
      const value = row[rule.field]
      const pretty = target === 'supplier_id'
        ? (context.suppliers ?? []).find((s) => s.id === value)?.name ?? value
        : (context.components ?? []).find((c) => c.id === value)?.name ?? value
      out.push([target.replace('_id', '').replace(/^\w/, (m) => m.toUpperCase()), pretty])
    }
    return out
  }, [spec, params, context])

  const add = () => {
    const clean = {}
    for (const f of spec.fields) {
      const v = params[f.name] ?? f.default
      if (v === undefined || v === '') continue
      clean[f.name] = (f.type === 'int') ? Number(v)
        : (f.type === 'number') ? Number(v) : v
    }
    setEvents((e) => [...e, { at_h: Number(atH || 0), type, params: clean,
                              note: note.trim() || null }]
      .sort((a, b) => a.at_h - b.at_h))
    setCheck(null)
    setNote('')
  }

  const validate = useMutation({
    mutationFn: () => api.validateScenario({ name: name || 'Untitled', events }),
    onSuccess: (r) => setCheck(r),
  })

  const json = JSON.stringify({ scenario_name: name || 'Untitled', events }, null, 2)

  return (
    <div className="flex flex-col gap-6">
      <div className="grid grid-cols-2 gap-3">
        <div>
          <Label_>Call this test</Label_>
          <Input value={name} onChange={(e) => setName(e.target.value)}
                 placeholder="Two suppliers fail at once" className="h-9 text-[12.5px]" />
        </div>
        <div>
          <Label_ hint="Narrows every dropdown below.">Focus on a part</Label_>
          <Select value={focus} onValueChange={setFocus}>
            <SelectTrigger className="h-9 text-[12.5px]">
              <SelectValue placeholder="everything" />
            </SelectTrigger>
            <SelectContent>
              {(context.components ?? []).map((c) => (
                <SelectItem key={c.id} value={c.id} className="text-[12.5px]">
                  {c.name}
                  {c.coverage_days != null && (
                    <span className="text-muted-foreground"> · {c.coverage_days}d cover</span>
                  )}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <Separator />

      {/* ------------------------------------------------- the event composer */}
      <div className="rounded-xl border p-4">
        <Label_>What happens</Label_>
        <Select value={type} onValueChange={setType}>
          <SelectTrigger className="h-9 w-full text-[12.5px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            {types.map((t) => (
              <SelectItem key={t} value={t} className="text-[12.5px]">
                {schema[t].label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {spec && (
          <>
            <p className="text-muted-foreground mt-2.5 text-[11.5px] leading-relaxed">
              {spec.blurb} <span className="opacity-75">Tests: {spec.tests}</span>
            </p>

            <div className="mt-4 flex flex-col gap-3.5">
              {spec.fields.map((f) => (
                <SchemaField key={f.name} field={f} context={context}
                             focusComponent={focus}
                             value={params[f.name]}
                             onChange={(v) => setParams((p) => ({ ...p, [f.name]: v }))} />
              ))}

              {derived.length > 0 && (
                <div className="bg-muted/40 rounded-lg px-3 py-2.5">
                  {derived.map(([k, v]) => (
                    <div key={k} className="flex items-center gap-2 text-[11.5px]">
                      <span className="text-muted-foreground">{k}</span>
                      <span className="font-medium">{v}</span>
                      <Badge variant="outline" className="ml-auto text-[9px]">
                        from the order
                      </Badge>
                    </div>
                  ))}
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label_ hint="1 real second = 1 simulated hour.">Fires at</Label_>
                  <Input type="number" min={0} value={atH}
                         onChange={(e) => setAtH(e.target.value)}
                         className="h-9 font-mono text-[12.5px] tabular-nums" />
                </div>
                <div>
                  <Label_>Note for the timeline</Label_>
                  <Input value={note} onChange={(e) => setNote(e.target.value)}
                         placeholder="why this one matters"
                         className="h-9 text-[12.5px]" />
                </div>
              </div>
            </div>

            <Button size="sm" disabled={missing.length > 0} onClick={add}
                    className="mt-4 h-9">
              <Plus className="size-3.5" />Add to the timeline
            </Button>
            {missing.length > 0 && (
              <p className="text-muted-foreground mt-2 text-[11px]">
                still needs: {missing.join(', ')}
              </p>
            )}
          </>
        )}
      </div>

      {/* --------------------------------------------------- entity creation */}
      {creating
        ? <NewSupplier context={context} onClose={() => setCreating(false)}
                       onCreated={() => setCreating(false)} />
        : <Button variant="outline" size="sm" onClick={() => setCreating(true)}
                  className="text-muted-foreground h-8 self-start text-[12px]">
            <Plus className="size-3.5" />New supplier — build your own trap
          </Button>}

      <Separator />

      {/* ------------------------------------------------------- the timeline */}
      <div>
        <Label_>Timeline</Label_>
        {events.length === 0 ? (
          <p className="text-muted-foreground text-[12px] leading-relaxed">
            Nothing yet. Add an event above — most interesting tests are two or three,
            where the second one invalidates what the agent concluded from the first.
          </p>
        ) : (
          <ol className="flex flex-col gap-2">
            {events.map((e, i) => (
              <li key={i} className="flex items-start gap-3 rounded-lg border px-3 py-2.5">
                <span className="text-muted-foreground w-11 shrink-0 pt-[1px] font-mono
                                 text-[11px] tabular-nums">+{e.at_h}h</span>
                <span className="min-w-0 flex-1">
                  <span className="block text-[12.5px] leading-snug">
                    {schema[e.type]?.label ?? e.type}
                  </span>
                  <span className="text-muted-foreground block font-mono text-[10.5px]
                                   leading-relaxed break-all">
                    {Object.entries(e.params).map(([k, v]) =>
                      `${k}=${String(v).slice(0, 40)}`).join(' · ')}
                  </span>
                  {e.note && (
                    <span className="text-muted-foreground/80 block text-[11px]">{e.note}</span>
                  )}
                </span>
                <Button variant="ghost" size="sm"
                        onClick={() => { setEvents((x) => x.filter((_, j) => j !== i));
                                         setCheck(null) }}
                        className="text-muted-foreground h-6 shrink-0 px-1.5">
                  <Trash2 className="size-3.5" />
                </Button>
              </li>
            ))}
          </ol>
        )}
      </div>

      {check && (
        <div className={`rounded-xl border px-4 py-3 text-[12px] leading-relaxed ${
          check.ok ? 'border-ok/40 bg-ok/[0.07]' : 'border-danger/40 bg-danger/[0.07]'}`}>
          {check.ok ? (
            <span className="flex items-start gap-2">
              <Check className="text-ok mt-0.5 size-3.5 shrink-0" />
              Valid. {check.events.length} event{check.events.length > 1 ? 's' : ''} over{' '}
              {check.span_sim_hours} simulated hours. Every ID it names exists.
            </span>
          ) : (
            <div className="text-danger flex flex-col gap-1.5">
              {check.errors.map((e, i) => (
                <span key={i} className="flex items-start gap-2">
                  <AlertTriangle className="mt-0.5 size-3.5 shrink-0" />{e}
                </span>
              ))}
            </div>
          )}
        </div>
      )}

      <div className="flex flex-wrap items-center gap-2.5">
        <Button variant="outline" size="sm" disabled={!events.length || validate.isPending}
                onClick={() => validate.mutate()} className="h-9">
          {validate.isPending ? <Loader2 className="size-3.5 animate-spin" />
                              : <Eye className="size-3.5" />}
          Validate
        </Button>
        <Button size="sm" disabled={!events.length || running}
                onClick={() => onRun({ name: name || 'Custom scenario', events, run: true })}
                className="h-9">
          {running ? <Loader2 className="size-3.5 animate-spin" />
                   : <Play className="size-3.5" />}
          Run this test
        </Button>
      </div>

      {events.length > 0 && (
        <details className="text-muted-foreground text-[11px]">
          <summary className="cursor-pointer select-none">
            what the builder just wrote
          </summary>
          <pre className="bg-muted/40 mt-2 overflow-x-auto rounded-lg p-3 font-mono
                          text-[10.5px] leading-relaxed">{json}</pre>
        </details>
      )}
    </div>
  )
}

/* ------------------------------------------------------------------ JSON -- */

function JsonTab({ schema, context, onRun, running }) {
  const [name, setName] = useState('')
  const [json, setJson] = useState(EXAMPLE)
  const [error, setError] = useState(null)
  const [check, setCheck] = useState(null)
  const [ref, setRef] = useState('')

  // Same as the builder: the schema lands after first paint.
  const refTypes = Object.keys(schema ?? {})
  useEffect(() => {
    if (!ref && refTypes.length) setRef(refTypes[0])
  }, [refTypes, ref])

  const parse = () => {
    try { return JSON.parse(json) } catch (e) {
      setError(`That is not valid JSON — ${e.message}`); return null
    }
  }

  const validate = useMutation({
    mutationFn: (events) => api.validateScenario({ name: name || 'Untitled', events }),
    onSuccess: (r) => { setError(null); setCheck(r) },
  })

  const spec = schema?.[ref]
  const idsFor = (type) => ({
    'ref:purchase_order': context.purchase_orders,
    'ref:component': context.components,
    'ref:supplier': context.suppliers,
    'ref:production_order': context.production_orders,
    'ref:warehouse': context.warehouses,
  }[type] ?? [])

  return (
    <div className="flex flex-col gap-5">
      <p className="text-muted-foreground text-[12px] leading-relaxed">
        For the eight-event adversarial timeline you want to write by hand. It goes
        into the same registry the built-ins live in and runs down the identical code
        path — there is no separate mode. Custom scenarios live in memory only and
        disappear when the server restarts.
      </p>

      <div>
        <Label_>Name it</Label_>
        <Input value={name} onChange={(e) => setName(e.target.value)}
               placeholder="Two suppliers fail at once" className="h-9 text-[12.5px]" />
      </div>

      <div>
        <Label_ hint="at_h is when it fires, in simulated hours from the start.">
          Events
        </Label_>
        <Textarea value={json} onChange={(e) => { setJson(e.target.value); setCheck(null) }}
                  spellCheck={false} rows={16}
                  className="font-mono text-[11px] leading-relaxed" />
      </div>

      {/* -------------------------------------------------- schema reference */}
      <div className="rounded-xl border p-4">
        <Label_>Schema reference</Label_>
        <Select value={ref} onValueChange={setRef}>
          <SelectTrigger className="h-9 w-full text-[12.5px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            {Object.keys(schema ?? {}).map((t) => (
              <SelectItem key={t} value={t} className="text-[12.5px]">
                <span className="font-mono">{t}</span>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {spec && (
          <div className="mt-3.5 flex flex-col gap-3">
            <p className="text-muted-foreground text-[11.5px] leading-relaxed">
              {spec.blurb}
            </p>
            <div>
              <div className="text-muted-foreground mb-1.5 text-[10px] font-medium
                              tracking-[0.12em] uppercase">Fields</div>
              <ul className="flex flex-col gap-1">
                {spec.fields.map((f) => (
                  <li key={f.name} className="flex items-baseline gap-2 text-[11.5px]">
                    <code className="font-mono">{f.name}</code>
                    <span className={f.required ? 'text-danger text-[10px]'
                                                : 'text-muted-foreground text-[10px]'}>
                      {f.required ? 'required' : 'optional'}
                    </span>
                    <span className="text-muted-foreground truncate">{f.label}</span>
                  </li>
                ))}
              </ul>
            </div>
            {spec.fields.filter((f) => f.type.startsWith('ref:')).map((f) => (
              <div key={f.name}>
                <div className="text-muted-foreground mb-1.5 text-[10px] font-medium
                                tracking-[0.12em] uppercase">
                  ids you can use for {f.name}
                </div>
                <div className="flex flex-col gap-1">
                  {idsFor(f.type).slice(0, 8).map((o) => (
                    <button key={o.id}
                            onClick={() => navigator.clipboard?.writeText(o.id)}
                            title="copy"
                            className="hover:bg-accent/50 flex items-baseline gap-2
                                       rounded px-1.5 py-1 text-left text-[11px]">
                      <code className="text-primary shrink-0 font-mono">{o.id}</code>
                      <span className="text-muted-foreground truncate">
                        {o.label ?? o.name}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {(error || check) && (
        <div className={`rounded-xl border px-4 py-3 text-[12px] leading-relaxed ${
          error || !check?.ok ? 'border-danger/40 bg-danger/[0.07]'
                              : 'border-ok/40 bg-ok/[0.07]'}`}>
          {error && (
            <span className="text-danger flex items-start gap-2">
              <AlertTriangle className="mt-0.5 size-3.5 shrink-0" />{error}
            </span>
          )}
          {check?.ok && (
            <span className="flex items-start gap-2">
              <Check className="text-ok mt-0.5 size-3.5 shrink-0" />
              Valid. {check.events.length} events over {check.span_sim_hours} simulated
              hours, and every ID exists.
            </span>
          )}
          {check && !check.ok && (
            <div className="text-danger flex flex-col gap-1.5">
              {check.errors.map((e, i) => (
                <span key={i} className="flex items-start gap-2">
                  <AlertTriangle className="mt-0.5 size-3.5 shrink-0" />{e}
                </span>
              ))}
            </div>
          )}
        </div>
      )}

      <div className="flex flex-wrap gap-2.5">
        <Button variant="outline" size="sm" disabled={validate.isPending} className="h-9"
                onClick={() => { const e = parse(); if (e) validate.mutate(e) }}>
          {validate.isPending ? <Loader2 className="size-3.5 animate-spin" />
                              : <Eye className="size-3.5" />}Validate
        </Button>
        <Button size="sm" disabled={running} className="h-9"
                onClick={() => {
                  const events = parse()
                  if (events) onRun({ name: name || 'Custom scenario', events, run: true })
                }}>
          {running ? <Loader2 className="size-3.5 animate-spin" />
                   : <Play className="size-3.5" />}Register and run
        </Button>
      </div>
    </div>
  )
}

/* ------------------------------------------------------------------ page -- */

export default function SimulationDrawer({ open, onOpenChange }) {
  const qc = useQueryClient()
  const [picked, setPicked] = useState(null)
  const [error, setError] = useState(null)
  const [note, setNote] = useState(null)

  const { data } = useQuery({
    queryKey: ['scenarios'], queryFn: api.scenarios,
    refetchInterval: open ? 2000 : false })
  const { data: ctx } = useQuery({
    queryKey: ['scenario-context'], queryFn: api.scenarioContext, enabled: open })

  const done = (msg) => { setError(null); setNote(msg ?? null); refresh(qc, 'simulation') }
  const fail = (e) => { setNote(null); setError(e.message) }

  const run = useMutation({ mutationFn: api.inject,
                            onSuccess: () => done(null), onError: fail })
  const custom = useMutation({
    mutationFn: api.customScenario,
    onSuccess: () => { done('Registered and running.'); onOpenChange(false) },
    onError: fail })
  const reset = useMutation({
    mutationFn: api.reset,
    onSuccess: (r) => done(r.history_preserved
      ? 'World re-seeded. Run history and the audit trail were kept.'
      : 'Everything wiped — world, run history and the audit trail.'),
    onError: fail })

  const scenarios = data?.scenarios ?? []
  const running = data?.running ?? []
  const selected = scenarios.find((s) => s.id === picked) ?? scenarios[0] ?? null

  // Read everything out up front. AnimatePresence re-renders the exiting child,
  // so any dereference of `selected` inside it crashes the instant it is null.
  const selId    = selected?.id ?? 'none'
  const selTitle = selected?.title ?? ''
  const selFeed  = selected?.feed ?? []
  const selCount = selected?.event_count ?? 0
  const selSpan  = selected?.span_sim_hours ?? 0
  const selWhy   = selected?.why ?? null
  const selWatch = selected?.watch_for ?? []

  const context = ctx ?? {}

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="flex w-full flex-col gap-0 p-0 sm:max-w-[38rem]">
        <SheetHeader className="gap-2 border-b px-7 py-6">
          <SheetTitle className="flex items-center gap-2.5 text-[18px]">
            <FlaskConical className="text-primary size-4.5" />Run a simulation
          </SheetTitle>
          <SheetDescription className="text-[13px] leading-relaxed">
            Each scenario feeds real events into the world on a simulated clock —
            one second of real time is one hour of plant time. The agent is never
            told which scenario is running, or what it is meant to conclude.
          </SheetDescription>
        </SheetHeader>

        <Tabs defaultValue="built-in" className="flex min-h-0 flex-1 flex-col gap-0">
          <TabsList className="mx-7 mt-5 w-auto self-start">
            <TabsTrigger value="built-in" className="text-[12.5px]">Built-in</TabsTrigger>
            <TabsTrigger value="builder" className="text-[12.5px]">Builder</TabsTrigger>
            <TabsTrigger value="json" className="text-[12.5px]">JSON</TabsTrigger>
          </TabsList>

          <TabsContent value="builder" className="min-h-0 flex-1">
            <ScrollArea className="h-full">
              <div className="p-7">
                <Builder schema={data?.event_schema} context={context}
                         running={custom.isPending}
                         onRun={(b) => custom.mutate(b)} />
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="json" className="min-h-0 flex-1">
            <ScrollArea className="h-full">
              <div className="p-7">
                <JsonTab schema={data?.event_schema} context={context}
                         running={custom.isPending}
                         onRun={(b) => custom.mutate(b)} />
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="built-in" className="min-h-0 flex-1">
            <ScrollArea className="h-full">
              <div className="flex flex-col gap-6 p-7">

                {running.length > 0 && (
                  <div className="border-primary/40 bg-primary/[0.07] flex items-center gap-2.5
                                  rounded-xl border px-4 py-3">
                    <Loader2 className="text-primary size-4 shrink-0 animate-spin" />
                    <span className="text-[13px]">
                      <b>{running.join(', ')}</b> is running now.
                    </span>
                  </div>
                )}

                {error && (
                  <div className="border-danger/40 bg-danger/[0.07] text-danger flex items-start
                                  gap-2 rounded-xl border px-4 py-3 text-[12.5px]">
                    <AlertTriangle className="mt-0.5 size-3.5 shrink-0" />{error}
                  </div>
                )}
                {note && (
                  <div className="border-ok/40 bg-ok/[0.07] flex items-start gap-2 rounded-xl
                                  border px-4 py-3 text-[12.5px]">
                    <Check className="text-ok mt-0.5 size-3.5 shrink-0" />{note}
                  </div>
                )}

                {/* pick one */}
                <div className="flex flex-col gap-2">
                  {scenarios.map((s) => {
                    const on = selected?.id === s.id
                    const live = running.includes(s.id)
                    return (
                      <button key={s.id} onClick={() => setPicked(s.id)}
                        className={`rounded-xl border px-4 py-3.5 text-left transition-colors
                          ${on ? 'border-primary/50 bg-primary/[0.06]' : 'hover:bg-accent/40'}`}>
                        <div className="flex items-center gap-2.5">
                          {on && <Check className="text-primary size-3.5 shrink-0" />}
                          <span className="text-[14px] font-medium">{s.title}</span>
                          {s.custom && (
                            <Badge variant="outline" className="shrink-0 text-[9.5px]">
                              yours
                            </Badge>
                          )}
                          {live && (
                            <Badge variant="outline"
                                   className="border-primary/40 bg-primary/10 text-primary ml-auto
                                              shrink-0 text-[10px]">live</Badge>
                          )}
                        </div>
                        <p className="text-muted-foreground mt-1.5 text-[12px] leading-relaxed">
                          {s.tests}
                        </p>
                      </button>
                    )
                  })}
                </div>

                {/* what it is for, and what it feeds in */}
                <AnimatePresence mode="wait">
                  {selFeed.length > 0 && (
                    <motion.div key={selId}
                                initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }}
                                exit={{ opacity: 0 }}>
                      <Separator className="mb-6" />

                      {selWhy && (
                        <div className="mb-6">
                          <h3 className="text-muted-foreground text-[10px] font-medium
                                         tracking-[0.14em] uppercase">
                            Why this test exists
                          </h3>
                          <p className="mt-2 text-[12.5px] leading-relaxed">{selWhy}</p>
                        </div>
                      )}

                      {selWatch.length > 0 && (
                        <div className="mb-6">
                          <h3 className="text-muted-foreground text-[10px] font-medium
                                         tracking-[0.14em] uppercase">
                            What to watch for
                          </h3>
                          <ul className="mt-2.5 flex flex-col gap-2">
                            {selWatch.map((w, i) => (
                              <li key={i} className="flex items-start gap-2.5 text-[12.5px]
                                                     leading-relaxed">
                                <Eye className="text-primary/70 mt-[3px] size-3.5 shrink-0" />
                                {w}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}

                      <h3 className="text-muted-foreground text-[10px] font-medium
                                     tracking-[0.14em] uppercase">
                        What gets fed in
                      </h3>
                      <p className="text-muted-foreground mt-2 text-[12px] leading-relaxed">
                        {selCount} event{selCount > 1 ? 's' : ''} over{' '}
                        {selSpan} simulated hours.
                      </p>

                      <ol className="mt-4 flex flex-col gap-3.5">
                        {selFeed.map((f, i) => (
                          <li key={i} className="flex gap-3">
                            <span className="text-muted-foreground w-10 shrink-0 pt-[1px]
                                             font-mono text-[11px] tabular-nums">
                              +{f.at_h}h
                            </span>
                            <span className="min-w-0">
                              <span className="block text-[13px] leading-snug">{f.what}</span>
                              {f.note && (
                                <span className="text-muted-foreground block text-[11.5px]
                                                 leading-relaxed">{f.note}</span>
                              )}
                            </span>
                          </li>
                        ))}
                      </ol>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>

        {/* the three things you can do */}
        <div className="flex items-center gap-2.5 border-t px-7 py-4">
          <Button size="lg" disabled={!selected || run.isPending}
                  onClick={() => selected && run.mutate(selected.id)}
                  className="h-10 flex-1">
            {run.isPending ? <Loader2 className="size-4 animate-spin" />
                           : <Play className="size-4" />}
            Run{selTitle ? ` “${selTitle.slice(0, 22)}”` : ''}
          </Button>

          <Button variant="outline" size="lg" disabled={reset.isPending}
                  onClick={() => reset.mutate('demo')} className="h-10"
                  title="Re-seed inventory, orders, shipments and conversations. Run history and the audit trail are kept.">
            {reset.isPending ? <Loader2 className="size-4 animate-spin" />
                             : <RotateCcw className="size-4" />}
            Reset
          </Button>

          <Button variant="outline" size="lg" disabled={reset.isPending}
                  onClick={() => {
                    if (window.confirm(
                      'Hard reset wipes the world AND every run score and audit event.\n\n'
                      + 'You lose the comparisons you have been tuning against. Use this '
                      + 'between sessions, never mid-demo.\n\nGo ahead?')) {
                      reset.mutate('hard')
                    }
                  }}
                  className="border-danger/40 text-danger hover:bg-danger/10 h-10"
                  title="Wipe everything, including run history and the audit trail.">
            <Trash2 className="size-4" />Hard
          </Button>
        </div>

        <p className="text-muted-foreground/70 px-7 pb-5 text-[11px] leading-relaxed">
          <b>Reset</b> re-seeds inventory, orders, shipments, conversations and open
          questions, and removes anything you created here — the audit log and past run
          scores survive, so you never lose the comparison you are tuning against.
          <b> Hard</b> takes those too.
        </p>
      </SheetContent>
    </Sheet>
  )
}
